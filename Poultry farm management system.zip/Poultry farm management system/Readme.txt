How to run the Poultry Farm Management System Project (PFMS)
1. Download the zip file

2. Extract the file and copy farm folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name poultry

6. Import poultry.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/farm

Admin Credential

Username: admin
Password: 1234


This project is free to use both personal and commercial

For commercial use, we recommend to first contact us to give support, improve on security and to add more useful functionalities

All our services are free don't fear to contact us on code4berryteam@gmail.com